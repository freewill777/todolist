# To-do
A simple todo list.
You can see it live [here](http://www.sfetq.ro/todo1)
## License
[MIT](LICENSE.md) © [Sfetcu Cristian](https://www.instagram.com/indianu__jones/)
